import json,re
MAP=[("มุทราธรรโมทัย","dharmodaya mudra"),("มณฑลกะปาละ","Kapala Mandala"),("เหรุกะวัชรสัตว์","Heruka Vajrasattva"),("ไวโรจนะเหรุกะ","Vairochana Heruka"),("วัชรสัตว์","Vajrasattva"),
("วัชรวาราหี","Vajravarahi"),("วัชรปาณี","Vajrapani"),("วัชรทากินี","Vajra Dakini"),("วัชรธร","Vajradhara"),("ไวโรจนะ","Vairochana"),("เหรุกะ","Heruka"),
("จักรสังวร","Chakrasamvara"),("ทากินี","Dakini"),("กะปาละ","Kapala"),("โตรมะ","Torma"),("ธรรโมทัย","Dharmodaya"),("ชญานสัตว์","jñana sattva"),
("สมยสัตว์","samaya sattva"),("มหามุทรา","Mahamudra"),("มุทรา","mudra"),("ยิดัม","Yidam"),("คุรุโยคะ","Guru Yoga"),("คุรุ","Guru"),("มณฑล","Mandala"),
("งอนโดร","Ngöndro"),("ทงเลน","Tonglen"),(" ซก "," tsok "),("บุมปะ","bumpa"),("พินทุ","bindu"),("นาทะ","nada"),("คัฏวางคะ","khatanga"),("ดามารุ","damaru"),
("อุฑฑิยานะ","Uddiyana"),("เนมา การ์โม","Nyema Karmo"),("ลลนา","lalanā"),("รสนา","rasanā"),("อวธูตี","avadhūtī"),("ริกปะ","rigpa"),("ยังซัล","Yang Sal"),
("เท็นยิง","Ten Nying"),("ทุมโม","tummo"),("สมันตภัทร","Samantabhadra"),("มัญชุศรี","Manjushri"),("เชนเรซิก","Chenrezig"),("มหากาฬ","Mahakala"),
("เหวัชระ","Hevajra"),("กาลจักร","Kalachakra"),("ติโลปะ","Tilopa"),("นาโรปะ","Naropa"),("มิลาเรปะ","Milarepa"),("มารปะ","Marpa"),("กัมโปปะ","Gampopa"),
("อักโษภยะ","Akshobhya"),("รัตนสัมภวะ","Ratnasambhava"),("อมิตาภะ","Amitabha"),("อโมฆสิทธิ","Amoghasiddhi")]
LAT='A-Za-zāīūṛṝḷṃḥñöśṣṭḍṅ'
def fix(t):
    if not re.search('[฀-๿]',t): return t
    for a,b in MAP: t=t.replace(a,b)
    t=re.sub(r'ตารา(?!ง)','Tara',t)
    t=re.sub(r'(?<=[a-z])(?=[A-Z])',' ',t)
    t=re.sub(r'(?<=['+LAT+r'])(?=[฀-๿])',' ',t)
    t=re.sub(r'(?<=[฀-๿])(?=['+LAT+r'])',' ',t)
    return t
FAM={'วัชระ':'Vajra','รัตนะ':'Ratna','ปัทมะ':'Padma','กรรมะ':'Karma','รัตนะ (อัญมณี)':'Ratna (Jewel)'}
tr=json.load(open('tr.json'))
en_cells={'Vajra','Ratna','Padma','Karma','Jewel'}
HEAD=set(json.load(open('headings.json')))
for k,v in list(tr['th'].items()):
    if k in HEAD: continue
    v=FAM.get(v,v) if k in en_cells else v
    tr['th'][k]=fix(v)
json.dump(tr,open('tr_build.json','w'),ensure_ascii=False)
s=open('vajrayogini.src.html').read()
A='/* ================= CONTENT ================= */'; B='const PLANS='
a=s.index(A); b=s.index(B)
chunk=re.sub(r"\n th:'((?:[^'\\]|\\.)*)'",lambda m:"\n th:'"+fix(m.group(1))+"'",s[a:b])
s=s[:a]+chunk+s[b:]
h0=s.index("th:[["); h1=s.index("]]\n};",h0)
s=s[:h0]+re.sub(r"'((?:[^'\\]|\\.)*)'",lambda m:"'"+fix(m.group(1))+"'",s[h0:h1])+s[h1:]
open('vajrayogini.build.html','w').write(s)
samples=[tr['th'][k] for k in ['Kapala Mandala — protection of the practice','Vajrayogini and 4 dakinis','Light from VAM at the heart (or HRI at the navel — connected to the inner practice): dakinis make offerings to Uddiyana and invite the wisdom hosts.','Body, speech & mind — to the gurus (Tilopa, Naropa, Marpa, Milarepa, Gampopa to all gurus), 5 Buddha families, 1,000 Buddhas, bodhisattvas, yidams (Vajrayogini, Chenrezig, Chakrasamvara, Hevajra, Kalachakra, Tara, Manjushri…), and Mahakala and protectors.','Part of body']]
for x in samples: print('-',x)
