ชุดไฟล์ต้นฉบับแอพวัชรโยคินี (Vajrayogini app source kit)
================================================
เก็บไว้เป็นความลับ ห้ามอัปโหลดขึ้น GitHub และห้ามส่งให้คนอื่น
- ไฟล์ในชุดนี้มีเนื้อหาคู่มือแบบไม่ล็อก และ "กุญแจหลัก" (kit_ck.txt)
- ใครได้ชุดนี้ไป จะเปิดอ่านเนื้อหาได้โดยไม่ต้องใช้รหัส

ใช้ทำอะไร
- เวลาต้องการแก้แอพ หรือเปลี่ยนรหัสในอนาคต ให้แนบไฟล์ zip นี้ส่งให้ Claude
- ถ้าไม่มีกุญแจหลัก (kit_ck.txt) การเปลี่ยนรหัสจะทำให้ทุกเครื่องต้องใส่รหัสใหม่หมด

Keep private. Do NOT upload to GitHub. Attach this zip when asking Claude to edit the app or change the password.
Build: python3 thfix.py (reads src) then node build2.js <src.build.html> index.html "<password>" images.json tr_build.json kit_ck.txt
