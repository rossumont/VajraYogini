// Build: node build2.js <src.html> <out.html> <passwords comma-separated> <images.json> <tr.json> <ck.txt>
// Content is encrypted with a fixed content key (ck.txt, created once, keep it!).
// Each password wraps that key in its own slot. Remove a password from the list = it stops working
// for new devices; devices that already opened the app keep the content key and stay unlocked.
const fs=require('fs'),vm=require('vm'),{webcrypto:c}=require('crypto');
const [,,src,out,pwList,imgF,trF,ckF]=process.argv;
let s=fs.readFileSync(src,'utf8');
const A='/* ================= CONTENT ================= */', B='const PLANS=';
const a=s.indexOf(A)+A.length, b=s.indexOf(B);
const chunk=s.slice(a,b).replace('__IMAGES__',fs.readFileSync(imgF,'utf8')).replace('__TR__',fs.readFileSync(trF,'utf8'));
const ctx={}; vm.runInNewContext(chunk+'\n;this.R={OUTER,INNER,IMG,TR,OFFEN:OFFER7,OFFTH:{th:"ARGHAM (น้ำ) · PUSHPE (ดอกไม้) · DHUPE (ธูป) · ALOKE (ประทีป) · GANDHE (น้ำหอม) · NEIVIDE (อาหาร) · SHAPTA (ดนตรี) — เติม AH HUM SVAHA ทุกอย่าง",zh:"ARGHAM（水）· PUSHPE（花）· DHUPE（香）· ALOKE（灯）· GANDHE（涂香）· NEIVIDE（食）· SHAPTA（乐）— 每项后加 AH HUM SVAHA"},MTEXT:{triple:{t:M.triple,tib:M.tripleTib},short:{t:M.short},harinisa:{t:M.innerVy},vs100:{t:M.heruka},vsshort:{t:"OM VAJRA SATTVA HUM"}}};',ctx);
const plain=new TextEncoder().encode(JSON.stringify(ctx.R));
const b64=u=>Buffer.from(u).toString('base64');
(async()=>{
 let ck;
 if(fs.existsSync(ckF)) ck=Buffer.from(fs.readFileSync(ckF,'utf8').trim(),'base64');
 else { ck=Buffer.from(c.getRandomValues(new Uint8Array(32))); fs.writeFileSync(ckF,b64(ck)); console.log('NEW content key created:',ckF); }
 const iter=250000;
 const key=await c.subtle.importKey('raw',ck,{name:'AES-GCM'},false,['encrypt']);
 const iv=c.getRandomValues(new Uint8Array(12));
 const ct=new Uint8Array(await c.subtle.encrypt({name:'AES-GCM',iv},key,plain));
 const slots=[];
 for(const pw of pwList.split(',').map(x=>x.trim()).filter(Boolean)){
   const norm=pw.toLowerCase().replace(/\s+/g,'');
   const salt=c.getRandomValues(new Uint8Array(16)), siv=c.getRandomValues(new Uint8Array(12));
   const base=await c.subtle.importKey('raw',new TextEncoder().encode(norm),'PBKDF2',false,['deriveKey']);
   const kek=await c.subtle.deriveKey({name:'PBKDF2',salt,iterations:iter,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt']);
   const w=new Uint8Array(await c.subtle.encrypt({name:'AES-GCM',iv:siv},kek,ck));
   slots.push({salt:b64(salt),iv:b64(siv),w:b64(w)});
 }
 const enc='\n// Guide content is encrypted (AES-GCM content key, unlocked by group password slots via PBKDF2)\nlet OUTER=[],INNER=[];\nconst ENC={v:2,iter:'+iter+',iv:"'+b64(iv)+'",ct:"'+b64(ct)+'",slots:'+JSON.stringify(slots)+'};\n\n';
 fs.writeFileSync(out,s.slice(0,a)+enc+s.slice(b));
 console.log('content',plain.length,'bytes; password slots:',slots.length);
})();
